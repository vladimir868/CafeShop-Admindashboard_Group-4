
import java.awt.print.PrinterException;
import java.text.MessageFormat;
import java.util.Date;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

import javax.swing.*;
import java.awt.print.PrinterException;


/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
public class cashierPay extends javax.swing.JFrame {

    /**
     * Creates new form cashierPay
     */
    public cashierPay() {
        initComponents();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jProgressBar1 = new javax.swing.JProgressBar();
        jPanel1 = new javax.swing.JPanel();
        jbtn7 = new javax.swing.JButton();
        jbtn8 = new javax.swing.JButton();
        jbtn5 = new javax.swing.JButton();
        jbtn4 = new javax.swing.JButton();
        jbtn6 = new javax.swing.JButton();
        jbtn1 = new javax.swing.JButton();
        jbtn2 = new javax.swing.JButton();
        jbtn3 = new javax.swing.JButton();
        jbtnDot = new javax.swing.JButton();
        jbtnC = new javax.swing.JButton();
        jbtn0 = new javax.swing.JButton();
        jbtn9 = new javax.swing.JButton();
        jPanel2 = new javax.swing.JPanel();
        jbtnFood1 = new javax.swing.JButton();
        jbtnFood2 = new javax.swing.JButton();
        jbtnFood3 = new javax.swing.JButton();
        jbtnFood4 = new javax.swing.JButton();
        jbtnFood5 = new javax.swing.JButton();
        jbtnFood6 = new javax.swing.JButton();
        jbtnFood7 = new javax.swing.JButton();
        jbtnFood8 = new javax.swing.JButton();
        jbtnFood10 = new javax.swing.JButton();
        jbtnFood11 = new javax.swing.JButton();
        jbtnFood12 = new javax.swing.JButton();
        jbtnFood9 = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jPanel3 = new javax.swing.JPanel();
        jPanel4 = new javax.swing.JPanel();
        jPanel5 = new javax.swing.JPanel();
        jPanel6 = new javax.swing.JPanel();
        jPanel7 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jtxtSubTotal = new javax.swing.JTextField();
        jtxtTax = new javax.swing.JTextField();
        jtxtTotal = new javax.swing.JTextField();
        jPanel8 = new javax.swing.JPanel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jtxtDisplay = new javax.swing.JTextField();
        jtxtChange = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        jcboPayment = new javax.swing.JComboBox<>();
        jPanel9 = new javax.swing.JPanel();
        jbtnPay = new javax.swing.JButton();
        jbtnReset = new javax.swing.JButton();
        jbtnPrint = new javax.swing.JButton();
        jbtnRemove = new javax.swing.JButton();
        jbtnExit = new javax.swing.JButton();
        jScrollPane2 = new javax.swing.JScrollPane();
        b = new javax.swing.JTextArea();
        jSlider1 = new javax.swing.JSlider();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel1.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jbtn7.setFont(new java.awt.Font("Tahoma", 1, 36)); // NOI18N
        jbtn7.setText("7");
        jbtn7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbtn7ActionPerformed(evt);
            }
        });
        jPanel1.add(jbtn7, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, 80, 70));

        jbtn8.setFont(new java.awt.Font("Tahoma", 1, 36)); // NOI18N
        jbtn8.setText("8");
        jbtn8.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbtn8ActionPerformed(evt);
            }
        });
        jPanel1.add(jbtn8, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 10, 80, 70));

        jbtn5.setFont(new java.awt.Font("Tahoma", 1, 36)); // NOI18N
        jbtn5.setText("5");
        jbtn5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbtn5ActionPerformed(evt);
            }
        });
        jPanel1.add(jbtn5, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 80, 80, 70));

        jbtn4.setFont(new java.awt.Font("Tahoma", 1, 36)); // NOI18N
        jbtn4.setText("4");
        jbtn4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbtn4ActionPerformed(evt);
            }
        });
        jPanel1.add(jbtn4, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 80, 80, 70));

        jbtn6.setFont(new java.awt.Font("Tahoma", 1, 36)); // NOI18N
        jbtn6.setText("6");
        jbtn6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbtn6ActionPerformed(evt);
            }
        });
        jPanel1.add(jbtn6, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 80, 80, 70));

        jbtn1.setFont(new java.awt.Font("Tahoma", 1, 36)); // NOI18N
        jbtn1.setText("1");
        jbtn1.addHierarchyListener(new java.awt.event.HierarchyListener() {
            public void hierarchyChanged(java.awt.event.HierarchyEvent evt) {
                jbtn1HierarchyChanged(evt);
            }
        });
        jbtn1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbtn1ActionPerformed(evt);
            }
        });
        jPanel1.add(jbtn1, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 150, 80, 70));

        jbtn2.setFont(new java.awt.Font("Tahoma", 1, 36)); // NOI18N
        jbtn2.setText("2");
        jbtn2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbtn2ActionPerformed(evt);
            }
        });
        jPanel1.add(jbtn2, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 150, 80, 70));

        jbtn3.setFont(new java.awt.Font("Tahoma", 1, 36)); // NOI18N
        jbtn3.setText("3");
        jbtn3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbtn3ActionPerformed(evt);
            }
        });
        jPanel1.add(jbtn3, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 150, 80, 70));

        jbtnDot.setFont(new java.awt.Font("Tahoma", 1, 36)); // NOI18N
        jbtnDot.setText(".");
        jbtnDot.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbtnDotActionPerformed(evt);
            }
        });
        jPanel1.add(jbtnDot, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 220, 80, 70));

        jbtnC.setFont(new java.awt.Font("Tahoma", 1, 36)); // NOI18N
        jbtnC.setText("C");
        jbtnC.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbtnCActionPerformed(evt);
            }
        });
        jPanel1.add(jbtnC, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 220, 80, 70));

        jbtn0.setFont(new java.awt.Font("Tahoma", 1, 36)); // NOI18N
        jbtn0.setText("0");
        jbtn0.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbtn0ActionPerformed(evt);
            }
        });
        jPanel1.add(jbtn0, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 220, 80, 70));

        jbtn9.setFont(new java.awt.Font("Tahoma", 1, 36)); // NOI18N
        jbtn9.setText("9");
        jbtn9.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbtn9ActionPerformed(evt);
            }
        });
        jPanel1.add(jbtn9, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 10, 80, 70));

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, 260, 310));

        jPanel2.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jPanel2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jbtnFood1.setFont(new java.awt.Font("Tahoma", 1, 36)); // NOI18N
        jbtnFood1.setText("F1");
        jbtnFood1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbtnFood1ActionPerformed(evt);
            }
        });
        jPanel2.add(jbtnFood1, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 20, 100, 90));

        jbtnFood2.setFont(new java.awt.Font("Tahoma", 1, 36)); // NOI18N
        jbtnFood2.setText("F2");
        jbtnFood2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbtnFood2ActionPerformed(evt);
            }
        });
        jPanel2.add(jbtnFood2, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 20, 100, 90));

        jbtnFood3.setFont(new java.awt.Font("Tahoma", 1, 36)); // NOI18N
        jbtnFood3.setText("F3");
        jbtnFood3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbtnFood3ActionPerformed(evt);
            }
        });
        jPanel2.add(jbtnFood3, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 20, 100, 90));

        jbtnFood4.setFont(new java.awt.Font("Tahoma", 1, 36)); // NOI18N
        jbtnFood4.setText("F4");
        jbtnFood4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbtnFood4ActionPerformed(evt);
            }
        });
        jPanel2.add(jbtnFood4, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 20, 100, 90));

        jbtnFood5.setFont(new java.awt.Font("Tahoma", 1, 36)); // NOI18N
        jbtnFood5.setText("F5");
        jbtnFood5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbtnFood5ActionPerformed(evt);
            }
        });
        jPanel2.add(jbtnFood5, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 110, 100, 90));

        jbtnFood6.setFont(new java.awt.Font("Tahoma", 1, 36)); // NOI18N
        jbtnFood6.setText("F6");
        jbtnFood6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbtnFood6ActionPerformed(evt);
            }
        });
        jPanel2.add(jbtnFood6, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 110, 100, 90));

        jbtnFood7.setFont(new java.awt.Font("Tahoma", 1, 36)); // NOI18N
        jbtnFood7.setText("F7");
        jbtnFood7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbtnFood7ActionPerformed(evt);
            }
        });
        jPanel2.add(jbtnFood7, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 110, 100, 90));

        jbtnFood8.setFont(new java.awt.Font("Tahoma", 1, 36)); // NOI18N
        jbtnFood8.setText("F8");
        jbtnFood8.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbtnFood8ActionPerformed(evt);
            }
        });
        jPanel2.add(jbtnFood8, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 110, 100, 90));

        jbtnFood10.setFont(new java.awt.Font("Tahoma", 1, 36)); // NOI18N
        jbtnFood10.setText("F10");
        jbtnFood10.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbtnFood10ActionPerformed(evt);
            }
        });
        jPanel2.add(jbtnFood10, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 200, 100, 90));

        jbtnFood11.setFont(new java.awt.Font("Tahoma", 1, 36)); // NOI18N
        jbtnFood11.setText("F11");
        jbtnFood11.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbtnFood11ActionPerformed(evt);
            }
        });
        jPanel2.add(jbtnFood11, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 200, 100, 90));

        jbtnFood12.setFont(new java.awt.Font("Tahoma", 1, 36)); // NOI18N
        jbtnFood12.setText("F12");
        jbtnFood12.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbtnFood12ActionPerformed(evt);
            }
        });
        jPanel2.add(jbtnFood12, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 200, 100, 90));

        jbtnFood9.setFont(new java.awt.Font("Tahoma", 1, 36)); // NOI18N
        jbtnFood9.setText("F9");
        jbtnFood9.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbtnFood9ActionPerformed(evt);
            }
        });
        jPanel2.add(jbtnFood9, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 200, 100, 90));

        getContentPane().add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(530, 10, 440, 310));

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Item", "Quantity", "Price"
            }
        ));
        jScrollPane1.setViewportView(jTable1);

        getContentPane().add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 10, 260, 310));

        jPanel3.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.LOWERED));
        jPanel3.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel4.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.LOWERED));
        jPanel4.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());
        jPanel3.add(jPanel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 330, 950, 140));

        jPanel5.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.LOWERED));
        jPanel5.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel6.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.LOWERED));
        jPanel6.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());
        jPanel5.add(jPanel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 330, 950, 140));

        jPanel3.add(jPanel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 330, 950, 140));

        jPanel7.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 22)); // NOI18N
        jLabel1.setText("Sub Total:");

        jLabel2.setFont(new java.awt.Font("Tahoma", 1, 22)); // NOI18N
        jLabel2.setText("Tax:");

        jLabel3.setFont(new java.awt.Font("Tahoma", 1, 22)); // NOI18N
        jLabel3.setText("Total:");

        jtxtSubTotal.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jtxtSubTotalActionPerformed(evt);
            }
        });

        jtxtTax.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jtxtTaxActionPerformed(evt);
            }
        });

        jtxtTotal.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jtxtTotalActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel7Layout = new javax.swing.GroupLayout(jPanel7);
        jPanel7.setLayout(jPanel7Layout);
        jPanel7Layout.setHorizontalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel7Layout.createSequentialGroup()
                        .addComponent(jLabel1)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jtxtSubTotal, javax.swing.GroupLayout.PREFERRED_SIZE, 146, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel7Layout.createSequentialGroup()
                        .addComponent(jLabel3)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jtxtTotal, javax.swing.GroupLayout.PREFERRED_SIZE, 146, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel7Layout.createSequentialGroup()
                        .addGap(59, 59, 59)
                        .addComponent(jLabel2)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jtxtTax, javax.swing.GroupLayout.PREFERRED_SIZE, 146, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(16, Short.MAX_VALUE))
        );
        jPanel7Layout.setVerticalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addGap(18, 18, 18)
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jtxtSubTotal))
                .addGap(18, 18, 18)
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 19, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jtxtTax))
                .addGap(18, 18, 18)
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(jtxtTotal))
                .addContainerGap(23, Short.MAX_VALUE))
        );

        jPanel3.add(jPanel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 20, 290, 160));

        jPanel8.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));

        jLabel4.setFont(new java.awt.Font("Tahoma", 1, 22)); // NOI18N
        jLabel4.setText("Payment:");

        jLabel5.setFont(new java.awt.Font("Tahoma", 1, 22)); // NOI18N
        jLabel5.setText("Cash:");

        jtxtDisplay.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jtxtDisplayActionPerformed(evt);
            }
        });

        jtxtChange.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jtxtChangeActionPerformed(evt);
            }
        });

        jLabel6.setFont(new java.awt.Font("Tahoma", 1, 22)); // NOI18N
        jLabel6.setText("Change:");

        jcboPayment.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jcboPayment.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Cash", "Gcash", "Credit Card" }));

        javax.swing.GroupLayout jPanel8Layout = new javax.swing.GroupLayout(jPanel8);
        jPanel8.setLayout(jPanel8Layout);
        jPanel8Layout.setHorizontalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel8Layout.createSequentialGroup()
                .addContainerGap(32, Short.MAX_VALUE)
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel5)
                    .addComponent(jLabel6))
                .addGap(18, 18, 18)
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jtxtChange)
                    .addComponent(jtxtDisplay)
                    .addComponent(jcboPayment, 0, 170, Short.MAX_VALUE))
                .addGap(10, 10, 10))
            .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPanel8Layout.createSequentialGroup()
                    .addGap(10, 10, 10)
                    .addComponent(jLabel4)
                    .addContainerGap(206, Short.MAX_VALUE)))
        );
        jPanel8Layout.setVerticalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel8Layout.createSequentialGroup()
                .addGap(23, 23, 23)
                .addComponent(jcboPayment, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 19, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jtxtDisplay))
                .addGap(18, 18, 18)
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jtxtChange)
                    .addComponent(jLabel6))
                .addGap(24, 24, 24))
            .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPanel8Layout.createSequentialGroup()
                    .addGap(15, 15, 15)
                    .addComponent(jLabel4, javax.swing.GroupLayout.DEFAULT_SIZE, 40, Short.MAX_VALUE)
                    .addGap(103, 103, 103)))
        );

        jPanel3.add(jPanel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 20, -1, 160));

        jPanel9.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));

        jbtnPay.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jbtnPay.setText("Pay");
        jbtnPay.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbtnPayActionPerformed(evt);
            }
        });

        jbtnReset.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jbtnReset.setText("Reset");
        jbtnReset.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbtnResetActionPerformed(evt);
            }
        });

        jbtnPrint.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jbtnPrint.setText("Print");
        jbtnPrint.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbtnPrintActionPerformed(evt);
            }
        });

        jbtnRemove.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jbtnRemove.setText("Remove");
        jbtnRemove.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbtnRemoveActionPerformed(evt);
            }
        });

        jbtnExit.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jbtnExit.setText("Exit");
        jbtnExit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbtnExitActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel9Layout = new javax.swing.GroupLayout(jPanel9);
        jPanel9.setLayout(jPanel9Layout);
        jPanel9Layout.setHorizontalGroup(
            jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel9Layout.createSequentialGroup()
                .addGap(17, 17, 17)
                .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel9Layout.createSequentialGroup()
                        .addComponent(jbtnPay, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jbtnReset, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jbtnExit, javax.swing.GroupLayout.PREFERRED_SIZE, 266, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel9Layout.createSequentialGroup()
                        .addComponent(jbtnPrint, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jbtnRemove, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(20, Short.MAX_VALUE))
        );
        jPanel9Layout.setVerticalGroup(
            jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel9Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jbtnPay, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jbtnReset, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jbtnRemove, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jbtnPrint, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addComponent(jbtnExit, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(15, Short.MAX_VALUE))
        );

        jPanel3.add(jPanel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(640, 20, -1, 160));

        getContentPane().add(jPanel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 340, 950, 200));

        b.setColumns(20);
        b.setRows(5);
        jScrollPane2.setViewportView(b);

        getContentPane().add(jScrollPane2, new org.netbeans.lib.awtextra.AbsoluteConstraints(980, 10, 360, 510));
        getContentPane().add(jSlider1, new org.netbeans.lib.awtextra.AbsoluteConstraints(980, 500, 310, -1));

        pack();
    }// </editor-fold>//GEN-END:initComponents
//============================Function=======================================
    public void ItemCost()
        {
            double sum = 0 ;
            for (int i = 0 ; i < jTable1.getRowCount(); i++)
            {
                sum = sum+ Double.parseDouble(jTable1.getValueAt(i, 2).toString());
            }
            jtxtSubTotal.setText(Double.toString(sum));
            double cTotal1 = Double.parseDouble(jtxtSubTotal.getText());

            double cTax = (cTotal1 * 0.12)/100;
            String iTaxTotal = String.format("₱ % .2f", cTax);
            jtxtTax.setText(iTaxTotal);

            String iSubTotal = String.format("₱ % .2f", cTotal1);
            jtxtSubTotal.setText(iSubTotal);

            String iTotal = String.format("₱ % .2f", cTotal1 + cTax);
            jtxtTotal.setText(iTotal);


        }

         //============================Function Change=======================================
        public void Change()
        {
        double sum = 0 ; 
    //    double tax = 3.9;
        double cash = Double.parseDouble(jtxtDisplay.getText());

        for (int i = 0 ; i < jTable1.getRowCount(); i++)
        {
            sum = sum + Double.parseDouble(jTable1.getValueAt(i, 2).toString());
            }
        double cTax = (sum * 0.12)/100;
    //    sum = sum + cTax; //adding tax
        if (Double.compare(cash, sum) > 0) {
            double cChange = (cash - (sum + cTax));
            String ChangeGiven = String.format("₱ % .2f", cChange);
            jtxtChange.setText(ChangeGiven);
        } else{
            JOptionPane.showMessageDialog(null, "Insufficient Payment.", "Error", JOptionPane.ERROR_MESSAGE);
        }

        }
    
    private void jbtn1HierarchyChanged(java.awt.event.HierarchyEvent evt) {//GEN-FIRST:event_jbtn1HierarchyChanged
        // TODO add your handling code here:
    }//GEN-LAST:event_jbtn1HierarchyChanged

    private void jtxtSubTotalActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jtxtSubTotalActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jtxtSubTotalActionPerformed

    private void jtxtTaxActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jtxtTaxActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jtxtTaxActionPerformed

    private void jtxtTotalActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jtxtTotalActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jtxtTotalActionPerformed

    private void jtxtDisplayActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jtxtDisplayActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jtxtDisplayActionPerformed

    private void jtxtChangeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jtxtChangeActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jtxtChangeActionPerformed

    private void jbtn7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbtn7ActionPerformed
       String Enternumber = jtxtDisplay.getText(); 
       if (Enternumber == "")
       {
           jtxtDisplay.setText(jbtn7.getText());
           
       }
       else
       {
           Enternumber = jtxtDisplay.getText() + jbtn7.getText();
           jtxtDisplay.setText(Enternumber);
       }
    }//GEN-LAST:event_jbtn7ActionPerformed

    private void jbtn8ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbtn8ActionPerformed
       String Enternumber = jtxtDisplay.getText(); 
       if (Enternumber == "")
       {
           jtxtDisplay.setText(jbtn8.getText());
           
       }
       else
       {
           Enternumber = jtxtDisplay.getText() + jbtn8.getText();
           jtxtDisplay.setText(Enternumber);
       }
    }//GEN-LAST:event_jbtn8ActionPerformed

    private void jbtn9ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbtn9ActionPerformed
       String Enternumber = jtxtDisplay.getText(); 
       if (Enternumber == "")
       {
           jtxtDisplay.setText(jbtn9.getText());
           
       }
       else
       {
           Enternumber = jtxtDisplay.getText() + jbtn9.getText();
           jtxtDisplay.setText(Enternumber);
       }    }//GEN-LAST:event_jbtn9ActionPerformed

    private void jbtn4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbtn4ActionPerformed
       String Enternumber = jtxtDisplay.getText(); 
       if (Enternumber == "")
       {
           jtxtDisplay.setText(jbtn4.getText());
           
       }
       else
       {
           Enternumber = jtxtDisplay.getText() + jbtn4.getText();
           jtxtDisplay.setText(Enternumber);
       }
    }//GEN-LAST:event_jbtn4ActionPerformed

    private void jbtn5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbtn5ActionPerformed
       String Enternumber = jtxtDisplay.getText(); 
       if (Enternumber == "")
       {
           jtxtDisplay.setText(jbtn5.getText());
           
       }
       else
       {
           Enternumber = jtxtDisplay.getText() + jbtn5.getText();
           jtxtDisplay.setText(Enternumber);
       }
    }//GEN-LAST:event_jbtn5ActionPerformed

    private void jbtn6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbtn6ActionPerformed
       String Enternumber = jtxtDisplay.getText(); 
       if (Enternumber == "")
       {
           jtxtDisplay.setText(jbtn6.getText());
           
       }
       else
       {
           Enternumber = jtxtDisplay.getText() + jbtn6.getText();
           jtxtDisplay.setText(Enternumber);
       }
    }//GEN-LAST:event_jbtn6ActionPerformed

    private void jbtn1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbtn1ActionPerformed
       String Enternumber = jtxtDisplay.getText(); 
       if (Enternumber == "")
       {
           jtxtDisplay.setText(jbtn1.getText());
           
       }
       else
       {
           Enternumber = jtxtDisplay.getText() + jbtn1.getText();
           jtxtDisplay.setText(Enternumber);
       }
    }//GEN-LAST:event_jbtn1ActionPerformed

    private void jbtn2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbtn2ActionPerformed
       String Enternumber = jtxtDisplay.getText(); 
       if (Enternumber == "")
       {
           jtxtDisplay.setText(jbtn2.getText());
           
       }
       else
       {
           Enternumber = jtxtDisplay.getText() + jbtn2.getText();
           jtxtDisplay.setText(Enternumber);
       }
    }//GEN-LAST:event_jbtn2ActionPerformed

    private void jbtn3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbtn3ActionPerformed
       String Enternumber = jtxtDisplay.getText(); 
       if (Enternumber == "")
       {
           jtxtDisplay.setText(jbtn3.getText());
           
       }
       else
       {
           Enternumber = jtxtDisplay.getText() + jbtn3.getText();
           jtxtDisplay.setText(Enternumber);
       }
    }//GEN-LAST:event_jbtn3ActionPerformed

    private void jbtnDotActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbtnDotActionPerformed
      if(! jtxtDisplay.getText().contains("."))
      {
          jtxtDisplay.setText(jtxtDisplay.getText()+jbtnDot.getText());
      }
    }//GEN-LAST:event_jbtnDotActionPerformed

    private void jbtn0ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbtn0ActionPerformed
       String Enternumber = jtxtDisplay.getText(); 
       if (Enternumber == "")
       {
           jtxtDisplay.setText(jbtn0.getText());
           
       }
       else
       {
           Enternumber = jtxtDisplay.getText() + jbtn0.getText();
           jtxtDisplay.setText(Enternumber);
       }
    }//GEN-LAST:event_jbtn0ActionPerformed

    private void jbtnCActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbtnCActionPerformed
       jtxtDisplay.setText("");
       jtxtChange.setText("");
    }//GEN-LAST:event_jbtnCActionPerformed

    private void jbtnFood1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbtnFood1ActionPerformed
       double PriceOfItem = 10;
       
       DefaultTableModel model = (DefaultTableModel) jTable1.getModel();
       model.addRow(new Object[]{"Food1", "1", PriceOfItem});
       ItemCost();
    }//GEN-LAST:event_jbtnFood1ActionPerformed

    private void jbtnFood2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbtnFood2ActionPerformed
       double PriceOfItem = 20;
       
       DefaultTableModel model = (DefaultTableModel) jTable1.getModel();
       model.addRow(new Object[]{"Food2", "1", PriceOfItem});
       ItemCost();
    }//GEN-LAST:event_jbtnFood2ActionPerformed

    private void jbtnFood3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbtnFood3ActionPerformed
           double PriceOfItem = 30;
       
       DefaultTableModel model = (DefaultTableModel) jTable1.getModel();
       model.addRow(new Object[]{"Food3", "1", PriceOfItem});
       ItemCost();
    }//GEN-LAST:event_jbtnFood3ActionPerformed

    private void jbtnFood4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbtnFood4ActionPerformed
               double PriceOfItem = 40;
       
       DefaultTableModel model = (DefaultTableModel) jTable1.getModel();
       model.addRow(new Object[]{"Food4", "1", PriceOfItem});
       ItemCost();
    }//GEN-LAST:event_jbtnFood4ActionPerformed

    private void jbtnFood5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbtnFood5ActionPerformed
               double PriceOfItem = 50;
       
       DefaultTableModel model = (DefaultTableModel) jTable1.getModel();
       model.addRow(new Object[]{"Food5", "1", PriceOfItem});
       ItemCost();
    }//GEN-LAST:event_jbtnFood5ActionPerformed

    private void jbtnFood6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbtnFood6ActionPerformed
               double PriceOfItem = 60;
       
       DefaultTableModel model = (DefaultTableModel) jTable1.getModel();
       model.addRow(new Object[]{"Food6", "1", PriceOfItem});
       ItemCost();
    }//GEN-LAST:event_jbtnFood6ActionPerformed

    private void jbtnFood7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbtnFood7ActionPerformed
               double PriceOfItem = 70;
       
       DefaultTableModel model = (DefaultTableModel) jTable1.getModel();
       model.addRow(new Object[]{"Food7", "1", PriceOfItem});
       ItemCost();
    }//GEN-LAST:event_jbtnFood7ActionPerformed

    private void jbtnFood8ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbtnFood8ActionPerformed
               double PriceOfItem = 80;
       
       DefaultTableModel model = (DefaultTableModel) jTable1.getModel();
       model.addRow(new Object[]{"Food8", "1", PriceOfItem});
       ItemCost();
    }//GEN-LAST:event_jbtnFood8ActionPerformed

    private void jbtnFood9ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbtnFood9ActionPerformed
              double PriceOfItem = 90;
       
       DefaultTableModel model = (DefaultTableModel) jTable1.getModel();
       model.addRow(new Object[]{"Food9", "1", PriceOfItem});
       ItemCost();
    }//GEN-LAST:event_jbtnFood9ActionPerformed

    private void jbtnFood10ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbtnFood10ActionPerformed
              double PriceOfItem = 100;
       
       DefaultTableModel model = (DefaultTableModel) jTable1.getModel();
       model.addRow(new Object[]{"Food10", "1", PriceOfItem});
       ItemCost();
    }//GEN-LAST:event_jbtnFood10ActionPerformed

    private void jbtnFood11ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbtnFood11ActionPerformed
       double PriceOfItem = 110;
       
       DefaultTableModel model = (DefaultTableModel) jTable1.getModel();
       model.addRow(new Object[]{"Food11", "1", PriceOfItem});
       ItemCost();
    }//GEN-LAST:event_jbtnFood11ActionPerformed

    private void jbtnFood12ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbtnFood12ActionPerformed
               double PriceOfItem = 120;
       
       DefaultTableModel model = (DefaultTableModel) jTable1.getModel();
       model.addRow(new Object[]{"Food12", "1", PriceOfItem});
       ItemCost();
    }//GEN-LAST:event_jbtnFood12ActionPerformed



    private void jbtnPayActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbtnPayActionPerformed
        if (jcboPayment.getSelectedItem().equals("Cash"))
        {
            Change();
        }
        else
        {
                jtxtChange.setText("");
                jtxtDisplay.setText("");
        }
    }//GEN-LAST:event_jbtnPayActionPerformed

    private void jbtnResetActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbtnResetActionPerformed
       DefaultTableModel model = (DefaultTableModel) jTable1.getModel();
       
       if (model.getRowCount()==0){
           JOptionPane.showMessageDialog(null, "Error: The table is empty. Cannot reset.", "Error", JOptionPane.ERROR_MESSAGE);
       }else{
           model.setRowCount(0);
           jtxtChange.setText("");
           jtxtTax.setText("");
           jtxtTotal.setText("");
           jtxtSubTotal.setText("");
           jtxtDisplay.setText("");
           
       }
       
    }//GEN-LAST:event_jbtnResetActionPerformed

    private void jbtnPrintActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbtnPrintActionPerformed
        DefaultTableModel model = (DefaultTableModel) jTable1.getModel();

            // Display the receipt in JTextArea
        try {
            // Clear existing content
            b.setText(""); 

            // Add header details
            b.append("     GROUP 4 - ENTERPRISES COOPERATION\n");
            b.append("     Kainan ni Mariel Arevalo\n");
            b.append("     Brgy Ming Ming, City of Sta. Castro, Laguna\n");
            b.append("     +63 123456789\n");
            b.append("     ------------------------------------------------\n");
            b.append("      Item\tQty\tPrice\n");
            b.append("     ------------------------------------------------\n");

            // Iterate through table rows and add each item to the receipt
            for (int i = 0; i < model.getRowCount(); i++) {
                String item = model.getValueAt(i, 0).toString();
                String qty = model.getValueAt(i, 1).toString();
                String price = model.getValueAt(i, 2).toString();

                // Ensure alignment with tabs and spaces
                b.append(String.format("     %-12s\t%-2s\t%3s\n ", item,  qty,  price));
            }

            // Add footer details
            b.append("     ------------------------------------------------\n");
            b.append(String.format("     Sub Total:   %s pesos\n", jtxtTotal.getText()));
            b.append(String.format("     Cash:        %s pesos\n", jtxtDisplay.getText()));
            b.append(String.format("     Change:      %s pesos\n", jtxtChange.getText()));
            b.append("     ------------------------------------------------\n");
            b.append("     Thank you and enjoy your meal...!\n");
            b.append("     ------------------------------------------------\n");
        } catch (Exception e) {
            System.out.println("Error displaying receipt: " + e.getMessage());
        }

        
        
        // Check if the table is empty
            if (model.getRowCount() == 0) {
                JOptionPane.showMessageDialog(null, "Error: No items in the table. Cannot print the receipt.", "Error", JOptionPane.ERROR_MESSAGE);
                return; // Stop further execution
            }

                // Check if the user has clicked "Pay" by verifying if payment details are provided
            if (jtxtChange.getText().isEmpty() || jtxtTotal.getText().isEmpty()) {
                JOptionPane.showMessageDialog(null, "Error: Please complete the payment before printing the receipt.", "Error", JOptionPane.ERROR_MESSAGE);
                return; // Stop further execution
            }
            
            // Construct the receipt content
           StringBuilder receipt = new StringBuilder();
           receipt.append("     GROUP 4 - ENTERPRISES COOPERATION\n");
           receipt.append("     Kainan ni Mariel Arevalo\n");
           receipt.append("     Brgy Ming Ming, City of Sta. Castro, Laguna\n");
           receipt.append("     +63 123456789\n");
           receipt.append("     ------------------------------------------------\n");
           receipt.append(String.format(     "%-15s %-5s %-10s\n", "     Item", "     Qty", "     Price"));
           receipt.append("     ------------------------------------------------\n");

           // Iterate through table rows and add each item to the receipt
           for (int i = 0; i < model.getRowCount(); i++) {
               String item = model.getValueAt(i, 0).toString();
               String qty = model.getValueAt(i, 1).toString();
               String price = model.getValueAt(i, 2).toString();
               receipt.append(String.format("     %-15s %-5s %-10s\n", item, qty, price));
           }

           receipt.append("     ------------------------------------------------\n");
           receipt.append("     Your total is: ").append(jtxtTotal.getText()).append("\n");
           receipt.append("     Cash: ").append(jtxtDisplay.getText()).append(" pesos\n");
           receipt.append("     Change: ").append(jtxtChange.getText()).append(" pesos\n");
           receipt.append("     ------------------------------------------------\n");
           receipt.append("     Thank you and enjoy your meal...!\n");
           receipt.append("     ------------------------------------------------\n");

           // Display the receipt in a JTextArea for printing
           JTextArea textArea = new JTextArea(receipt.toString());
           try {
               textArea.print();
           } catch (java.awt.print.PrinterException e) {
               JOptionPane.showMessageDialog(null, "No printer found: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
           }
    }//GEN-LAST:event_jbtnPrintActionPerformed

    private void jbtnRemoveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbtnRemoveActionPerformed
        DefaultTableModel model = (DefaultTableModel) jTable1.getModel();

        // Get the index of the selected row
        int RemoveItem = jTable1.getSelectedRow();

        if (RemoveItem >= 0) {
            // Remove the selected row if an item is selected
            model.removeRow(RemoveItem);
            ItemCost(); // Update item cost

            // Check the payment type and perform appropriate actions
            if (jcboPayment.getSelectedItem().equals("Cash")) {
                Change();
            } else {
                jtxtChange.setText("");
                jtxtDisplay.setText("");
            }
        } else {
            // Show an error message if no item is selected
            JOptionPane.showMessageDialog(null, "Please select an item you want to remove.", "Error", JOptionPane.ERROR_MESSAGE);
        }



//        DefaultTableModel model = (DefaultTableModel) jTable1.getModel();
//        
//        int RemoveItem = jTable1.getSelectedRow();
//        if (RemoveItem >=0)
//        {
//        model.removeRow(RemoveItem);
//        }
//        ItemCost();
//        
//        if (jcboPayment.getSelectedItem().equals("Cash"))
//            {
//                Change();
//            }
//            else
//                {
//                    jtxtChange.setText("");
//                    jtxtDisplay.setText("");
//                }
    }//GEN-LAST:event_jbtnRemoveActionPerformed

    private JFrame frame;
    
    private void jbtnExitActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbtnExitActionPerformed
        
        frame = new JFrame("Exit");
        if (JOptionPane.showConfirmDialog(frame, "Do you want to exit?","GROUP 4",
                JOptionPane.YES_NO_OPTION) == JOptionPane.YES_NO_OPTION)
        {
            System.exit(0);
        }
    }//GEN-LAST:event_jbtnExitActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(cashierPay.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(cashierPay.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(cashierPay.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(cashierPay.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new cashierPay().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextArea b;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JPanel jPanel8;
    private javax.swing.JPanel jPanel9;
    private javax.swing.JProgressBar jProgressBar1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JSlider jSlider1;
    private javax.swing.JTable jTable1;
    private javax.swing.JButton jbtn0;
    private javax.swing.JButton jbtn1;
    private javax.swing.JButton jbtn2;
    private javax.swing.JButton jbtn3;
    private javax.swing.JButton jbtn4;
    private javax.swing.JButton jbtn5;
    private javax.swing.JButton jbtn6;
    private javax.swing.JButton jbtn7;
    private javax.swing.JButton jbtn8;
    private javax.swing.JButton jbtn9;
    private javax.swing.JButton jbtnC;
    private javax.swing.JButton jbtnDot;
    private javax.swing.JButton jbtnExit;
    private javax.swing.JButton jbtnFood1;
    private javax.swing.JButton jbtnFood10;
    private javax.swing.JButton jbtnFood11;
    private javax.swing.JButton jbtnFood12;
    private javax.swing.JButton jbtnFood2;
    private javax.swing.JButton jbtnFood3;
    private javax.swing.JButton jbtnFood4;
    private javax.swing.JButton jbtnFood5;
    private javax.swing.JButton jbtnFood6;
    private javax.swing.JButton jbtnFood7;
    private javax.swing.JButton jbtnFood8;
    private javax.swing.JButton jbtnFood9;
    private javax.swing.JButton jbtnPay;
    private javax.swing.JButton jbtnPrint;
    private javax.swing.JButton jbtnRemove;
    private javax.swing.JButton jbtnReset;
    private javax.swing.JComboBox<String> jcboPayment;
    private javax.swing.JTextField jtxtChange;
    private javax.swing.JTextField jtxtDisplay;
    private javax.swing.JTextField jtxtSubTotal;
    private javax.swing.JTextField jtxtTax;
    private javax.swing.JTextField jtxtTotal;
    // End of variables declaration//GEN-END:variables
}
